import torch
from pixellib.torchbackend.instance import instanceSegmentation
import cv2
capture = cv2.VideoCapture(0)
#capture = cv2.VideoCapture('C:/Users/gopal/Downloads/source-code-face-recognition/source code/video.MOV')
segment_video = instanceSegmentation()
segment_video.load_model("pointrend_resnet50.pkl", detection_speed='rapid')
target_classes=segment_video.select_target_classes(car=True,person=True,motorcycle=True,bicycle=True,bus=True,truck=True)
segment_video.process_camera(capture,segment_target_classes=target_classes, show_bboxes = True, frames_per_second= 30, extract_segmented_objects=True, extract_from_box=True,
save_extracted_objects=True, show_frames= True,frame_name= "frame", output_video_name="output_video.mp4", check_fps=True,mask_points_values=True)

'''
import pixellib
from pixellib.semantic import semantic_segmentation

segment_video = semantic_segmentation()
segment_video.load_ade20k_model("deeplabv3_xception65_ade20k.h5")
segment_video.process_video_ade20k("video.mp4", overlay=True, frames_per_second=15,
                                   output_video_name="output_video.mp4")'''